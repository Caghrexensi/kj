module.exports = {
    baseUrl: 'https://otakudesu.org/',
    completeAnime:'complete-anime/',
    onGoingAnime:'ongoing-anime/',
    schedule:'jadwal-rilis/',
    genreList:'genre-list/'
};